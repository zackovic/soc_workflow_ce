module.exports = function () {
    return new Promise((resolve, reject) => {
        resolve({});
    });
};