/**
 * @param server
 * @param req
 */
module.exports = function (server, req) {
    return new Promise((resolve, reject) => {
        resolve(['SOC Operator']);
    });
};