require('ui/modules').get('app/soc_workflow_ce', []).directive('spEditCaseGraphWorkspace', [
    function () {
        return {
            template: ''
        }
    }]);