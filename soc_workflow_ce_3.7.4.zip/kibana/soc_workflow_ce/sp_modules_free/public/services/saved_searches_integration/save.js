require('ui/modules').get('app/soc_workflow_ce', []).service('spSavedSearchIntegrationSave', [function () {
    return function ($scope, data) {
    };
}]);
