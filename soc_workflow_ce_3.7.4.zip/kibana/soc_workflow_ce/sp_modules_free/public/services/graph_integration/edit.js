require('ui/modules').get('app/soc_workflow_ce', []).service('spGraphIntegrationEdit', [
    function () {
        return false;
    }]);
