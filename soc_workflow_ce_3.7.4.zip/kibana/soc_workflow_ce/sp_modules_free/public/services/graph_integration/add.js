require('ui/modules').get('app/soc_workflow_ce', []).service('spGraphIntegrationAdd', [
    function () {
        return function ($scope, newValue) {};
    }]);
