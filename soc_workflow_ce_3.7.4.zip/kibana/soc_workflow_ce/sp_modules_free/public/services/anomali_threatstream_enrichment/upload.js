require('ui/modules').get('app/soc_workflow_ce', []).service('spUploadToAnomaliMyAttacks', [function () {
    return function ($scope) {
        return false;
    };
}]);
