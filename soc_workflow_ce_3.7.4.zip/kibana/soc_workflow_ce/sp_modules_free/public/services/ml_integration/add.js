require('ui/modules').get('app/soc_workflow_ce', [])
    .service('spMlIntegrationAdd', [
        function () {
            return function ($scope, newValue) {
            };
        }]);
