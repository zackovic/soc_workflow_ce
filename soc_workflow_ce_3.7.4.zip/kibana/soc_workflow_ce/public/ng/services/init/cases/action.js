require('ui/modules').get('app/soc_workflow_ce', [])
    .service('spInitCasesAction', ['modal', function (modal) {
        return function ($scope) {
        }
    }]);
